allennlp.common.registrable
===============================

.. automodule:: allennlp.common.registrable
   :members:
   :undoc-members:
   :show-inheritance:

