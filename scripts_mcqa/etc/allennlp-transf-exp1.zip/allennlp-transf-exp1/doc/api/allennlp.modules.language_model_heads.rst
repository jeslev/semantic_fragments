allennlp.modules.language_model_heads
=====================================

.. automodule:: allennlp.modules.language_model_heads
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.language_model_heads.language_model_head
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.language_model_heads.bert
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.language_model_heads.gpt2
   :members:
   :undoc-members:
   :show-inheritance:
