allennlp.semparse.domain_languages
==================================

.. automodule:: allennlp.semparse.domain_languages
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.domain_languages.domain_language
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.domain_languages.quarel_language
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.domain_languages.nlvr_language
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.domain_languages.wikitables_language
   :members:
   :undoc-members:
   :show-inheritance:
