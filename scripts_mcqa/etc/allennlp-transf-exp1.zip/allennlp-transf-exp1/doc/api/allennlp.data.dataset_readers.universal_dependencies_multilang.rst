allennlp.data.dataset_readers.universal_dependencies_multilang
==============================================================

.. automodule:: allennlp.data.dataset_readers.universal_dependencies_multilang
   :members:
   :undoc-members:
   :show-inheritance:
