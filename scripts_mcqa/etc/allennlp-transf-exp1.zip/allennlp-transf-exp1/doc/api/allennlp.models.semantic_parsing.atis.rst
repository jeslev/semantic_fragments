allennlp.models.semantic_parsing.atis
===========================================

.. automodule:: allennlp.models.semantic_parsing.atis
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.semantic_parsing.atis.atis_semantic_parser
   :members:
   :undoc-members:
   :show-inheritance:
