allennlp.pretrained
===================

Pretrained models available in AllenNLP.

.. automodule:: allennlp.pretrained
   :members:
   :undoc-members:
   :show-inheritance:
