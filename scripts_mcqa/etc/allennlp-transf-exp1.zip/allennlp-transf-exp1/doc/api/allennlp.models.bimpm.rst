allennlp.models.bimpm
========================

.. automodule:: allennlp.models.bimpm
   :members:
   :undoc-members:
   :show-inheritance:
