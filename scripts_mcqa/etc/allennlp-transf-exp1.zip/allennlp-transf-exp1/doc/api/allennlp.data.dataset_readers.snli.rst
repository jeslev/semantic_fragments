allennlp.data.dataset_readers.snli
==================================

.. automodule:: allennlp.data.dataset_readers.snli
   :members:
   :undoc-members:
   :show-inheritance:
