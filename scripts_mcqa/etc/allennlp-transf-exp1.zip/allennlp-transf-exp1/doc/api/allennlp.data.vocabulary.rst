allennlp.data.vocabulary
========================

.. automodule:: allennlp.data.vocabulary
   :members:
   :undoc-members:
   :show-inheritance:
