allennlp.data.dataset_readers.multiprocess_dataset_reader
===========================================================

.. automodule:: allennlp.data.dataset_readers.multiprocess_dataset_reader
   :members:
   :undoc-members:
   :show-inheritance:
