allennlp.data.dataset_readers.text_classification_json
======================================================

.. automodule:: allennlp.data.dataset_readers.text_classification_json
   :members:
   :undoc-members:
   :show-inheritance:
