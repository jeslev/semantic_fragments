allennlp.models.reading_comprehension
=====================================

.. automodule:: allennlp.models.reading_comprehension
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.bidaf
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.bidaf_ensemble
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.dialog_qa
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.qanet
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.naqanet
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.util
   :members:
   :undoc-members:
   :show-inheritance:
