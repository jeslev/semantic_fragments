allennlp.training.moving_average
======================================

.. automodule:: allennlp.training.moving_average
   :members:
   :undoc-members:
   :show-inheritance:
