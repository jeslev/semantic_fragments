allennlp.data.dataset_readers.semantic_parsing.wikitables
=========================================================

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.wikitables
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.wikitables.wikitables
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.wikitables.util
   :members:
   :undoc-members:
   :show-inheritance:
