allennlp.data.dataset_readers.event2mind
========================================

.. automodule:: allennlp.data.dataset_readers.event2mind
   :members:
   :undoc-members:
   :show-inheritance:
