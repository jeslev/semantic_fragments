allennlp.models.basic_classifier
================================

.. automodule:: allennlp.models.basic_classifier
   :members:
   :undoc-members:
   :show-inheritance:
