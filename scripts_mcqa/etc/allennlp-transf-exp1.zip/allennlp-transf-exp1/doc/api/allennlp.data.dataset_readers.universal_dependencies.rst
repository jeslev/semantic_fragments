allennlp.data.dataset_readers.universal_dependencies
=====================================================

.. automodule:: allennlp.data.dataset_readers.universal_dependencies
   :members:
   :undoc-members:
   :show-inheritance:
