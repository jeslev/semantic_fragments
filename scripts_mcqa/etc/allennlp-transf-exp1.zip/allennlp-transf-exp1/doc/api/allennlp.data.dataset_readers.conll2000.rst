allennlp.data.dataset_readers.conll2000
=======================================

.. automodule:: allennlp.data.dataset_readers.conll2000
   :members:
   :undoc-members:
   :show-inheritance:
