allennlp.models.biattentive_classification_network
==================================================

.. automodule:: allennlp.models.biattentive_classification_network
   :members:
   :undoc-members:
   :show-inheritance:
