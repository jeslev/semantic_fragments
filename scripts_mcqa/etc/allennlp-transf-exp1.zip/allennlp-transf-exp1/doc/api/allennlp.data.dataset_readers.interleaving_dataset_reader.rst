allennlp.data.dataset_readers.interleaving_dataset_reader
=========================================================

.. automodule:: allennlp.data.dataset_readers.interleaving_dataset_reader
   :members:
   :undoc-members:
   :show-inheritance:
