allennlp.models.srl_bert
========================

.. automodule:: allennlp.models.srl_bert
   :members:
   :undoc-members:
   :show-inheritance:
