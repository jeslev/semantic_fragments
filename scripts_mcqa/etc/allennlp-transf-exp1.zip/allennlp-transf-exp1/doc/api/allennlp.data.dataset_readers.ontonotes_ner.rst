allennlp.data.dataset_readers.ontonotes_ner
===========================================

.. automodule:: allennlp.data.dataset_readers.ontonotes_ner
   :members:
   :undoc-members:
   :show-inheritance:
