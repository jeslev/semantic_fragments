allennlp.models.biaffine_dependency_parser
==========================================

.. automodule:: allennlp.models.biaffine_dependency_parser
   :members:
   :undoc-members:
   :show-inheritance:
