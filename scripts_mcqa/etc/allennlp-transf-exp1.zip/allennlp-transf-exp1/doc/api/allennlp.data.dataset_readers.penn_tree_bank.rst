allennlp.data.dataset_readers.penn_tree_bank
====================================================

.. automodule:: allennlp.data.dataset_readers.penn_tree_bank
   :members:
   :undoc-members:
   :show-inheritance:
