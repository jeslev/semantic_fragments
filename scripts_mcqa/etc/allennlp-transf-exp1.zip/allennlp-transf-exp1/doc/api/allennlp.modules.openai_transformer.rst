allennlp.modules.openai_transformer
===================================

.. automodule:: allennlp.modules.openai_transformer
   :members:
   :undoc-members:
   :show-inheritance:
