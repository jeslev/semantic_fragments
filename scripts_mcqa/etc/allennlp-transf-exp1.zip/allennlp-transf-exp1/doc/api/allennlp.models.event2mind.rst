allennlp.models.event2mind
==========================

.. automodule:: allennlp.models.event2mind
   :members:
   :undoc-members:
   :show-inheritance:
