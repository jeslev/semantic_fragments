allennlp.interpret.attackers
============================

.. automodule:: allennlp.interpret.attackers
   :members:
   :undoc-members:
   :show-inheritance:

* :ref:`Attacker<attacker>`
* :ref:`HotFlip<hotflip>`
* :ref:`InputReduction<input-reduction>`
* :ref:`utils<utils>`

.. _attacker:
.. automodule:: allennlp.interpret.attackers.attacker
   :members:
   :undoc-members:
   :show-inheritance:

.. _hotflip:
.. automodule:: allennlp.interpret.attackers.hotflip
   :members:
   :undoc-members:
   :show-inheritance:

.. _input-reduction:
.. automodule:: allennlp.interpret.attackers.input_reduction
   :members:
   :undoc-members:
   :show-inheritance:

.. _utils:
.. automodule:: allennlp.interpret.attackers.utils
   :members:
   :undoc-members:
   :show-inheritance:
