allennlp.semparse.contexts
==========================

.. automodule:: allennlp.semparse.contexts
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.knowledge_graph
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.table_question_context
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.atis_tables
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.atis_sql_table_context
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.text2sql_table_context
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.sql_context_utils
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.quarel_utils
   :members:
   :undoc-members:
   :show-inheritance:
