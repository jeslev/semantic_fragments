allennlp.modules.matrix_attention
=========================================

.. automodule:: allennlp.modules.matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.matrix_attention.matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.matrix_attention.bilinear_matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.matrix_attention.cosine_matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.matrix_attention.dot_product_matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.matrix_attention.linear_matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.matrix_attention.legacy_matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:
