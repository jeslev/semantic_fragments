allennlp.commands.configure
===========================

.. automodule:: allennlp.commands.configure
