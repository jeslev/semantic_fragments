allennlp.models.crf_tagger
=========================================

.. automodule:: allennlp.models.crf_tagger
   :members:
   :undoc-members:
   :show-inheritance:
