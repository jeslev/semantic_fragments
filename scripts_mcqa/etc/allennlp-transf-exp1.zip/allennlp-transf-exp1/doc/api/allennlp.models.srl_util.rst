allennlp.models.srl_util
========================

.. automodule:: allennlp.models.srl_util
   :members:
   :undoc-members:
   :show-inheritance:
