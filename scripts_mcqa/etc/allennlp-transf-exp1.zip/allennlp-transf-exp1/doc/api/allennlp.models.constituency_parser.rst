allennlp.models.constituency_parser
===================================

.. automodule:: allennlp.models.constituency_parser
   :members:
   :undoc-members:
   :show-inheritance:
