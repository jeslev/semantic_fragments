allennlp.models.bert_for_classification
=======================================

.. automodule:: allennlp.models.bert_for_classification
   :members:
   :undoc-members:
   :show-inheritance:
