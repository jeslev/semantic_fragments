allennlp.models.esim
====================

.. automodule:: allennlp.models.esim
   :members:
   :undoc-members:
   :show-inheritance:
