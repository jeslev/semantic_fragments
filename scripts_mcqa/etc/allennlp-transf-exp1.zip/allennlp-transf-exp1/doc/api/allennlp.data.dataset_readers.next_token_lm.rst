allennlp.data.dataset_readers.next_token_lm
===========================================

.. automodule:: allennlp.data.dataset_readers.next_token_lm
   :members:
   :undoc-members:
   :show-inheritance:
