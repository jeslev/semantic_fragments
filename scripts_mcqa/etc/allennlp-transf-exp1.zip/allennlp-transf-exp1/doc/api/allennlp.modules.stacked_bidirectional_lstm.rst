allennlp.modules.stacked_bidirectional_lstm
===========================================

.. automodule:: allennlp.modules.stacked_bidirectional_lstm
   :members:
   :undoc-members:
   :show-inheritance:
