allennlp.models.semantic_parsing
================================

.. automodule:: allennlp.models.semantic_parsing
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.semantic_parsing.text2sql_parser
   :members:
   :undoc-members:
   :show-inheritance:

.. toctree::

  allennlp.models.semantic_parsing.nlvr
  allennlp.models.semantic_parsing.wikitables
  allennlp.models.semantic_parsing.atis
  allennlp.models.semantic_parsing.quarel
