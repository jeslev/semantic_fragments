allennlp.semparse.worlds
=============================

.. automodule:: allennlp.semparse.worlds
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.worlds.world
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.worlds.atis_world
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.worlds.text2sql_world
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.worlds.quarel_world
   :members:
   :undoc-members:
   :show-inheritance:
