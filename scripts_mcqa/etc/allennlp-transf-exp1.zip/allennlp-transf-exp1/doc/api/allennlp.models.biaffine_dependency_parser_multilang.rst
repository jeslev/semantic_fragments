allennlp.models.biaffine_dependency_parser_multilang
====================================================

.. automodule:: allennlp.models.biaffine_dependency_parser_multilang
   :members:
   :undoc-members:
   :show-inheritance:
