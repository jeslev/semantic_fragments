allennlp.data.dataset_readers.simple_language_modeling
======================================================

.. automodule:: allennlp.data.dataset_readers.simple_language_modeling
   :members:
   :undoc-members:
   :show-inheritance:
