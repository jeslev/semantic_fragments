allennlp.data.dataset_readers.babi
==================================

.. automodule:: allennlp.data.dataset_readers.babi
   :members:
   :undoc-members:
   :show-inheritance:
