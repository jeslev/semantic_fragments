allennlp.commands.subcommand
============================

.. automodule:: allennlp.commands.subcommand
   :members:
