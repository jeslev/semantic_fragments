allennlp.models.semantic_parsing.quarel
=======================================

.. automodule:: allennlp.models.semantic_parsing.quarel
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.semantic_parsing.quarel.quarel_semantic_parser
   :members:
   :undoc-members:
   :show-inheritance:
