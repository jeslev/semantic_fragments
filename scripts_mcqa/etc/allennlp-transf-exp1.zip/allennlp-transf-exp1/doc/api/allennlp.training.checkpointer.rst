allennlp.training.checkpointer
======================================

.. automodule:: allennlp.training.checkpointer
   :members:
   :undoc-members:
   :show-inheritance:
