allennlp.data.dataset_readers.quora_paraphrase
=====================================================

.. automodule:: allennlp.data.dataset_readers.quora_paraphrase
   :members:
   :undoc-members:
   :show-inheritance:
