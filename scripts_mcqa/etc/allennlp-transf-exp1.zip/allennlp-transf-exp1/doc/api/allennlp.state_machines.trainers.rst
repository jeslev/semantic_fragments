allennlp.state_machines.trainers
================================

.. automodule:: allennlp.state_machines.trainers
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.state_machines.trainers.decoder_trainer
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.state_machines.trainers.maximum_marginal_likelihood
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.state_machines.trainers.expected_risk_minimization
   :members:
   :undoc-members:
   :show-inheritance:
