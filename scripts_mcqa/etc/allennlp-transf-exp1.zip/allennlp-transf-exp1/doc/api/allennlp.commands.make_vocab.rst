allennlp.commands.make_vocab
============================

.. automodule:: allennlp.commands.make_vocab
