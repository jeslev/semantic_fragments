allennlp.models.semantic_parsing.nlvr
=====================================

.. automodule:: allennlp.models.semantic_parsing.nlvr
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.semantic_parsing.nlvr.nlvr_semantic_parser
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.semantic_parsing.nlvr.nlvr_coverage_semantic_parser
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.semantic_parsing.nlvr.nlvr_direct_semantic_parser
   :members:
   :undoc-members:
   :show-inheritance:
