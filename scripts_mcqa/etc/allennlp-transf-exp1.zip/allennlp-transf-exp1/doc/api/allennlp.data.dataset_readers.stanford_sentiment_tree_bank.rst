allennlp.data.dataset_readers.stanford_sentiment_tree_bank
==========================================================

.. automodule:: allennlp.data.dataset_readers.stanford_sentiment_tree_bank
   :members:
   :undoc-members:
   :show-inheritance:
