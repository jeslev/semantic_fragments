allennlp.interpret
==================

These submodules contain various functionality for interpreting model predictions.

.. toctree::

   allennlp.interpret.attackers
   allennlp.interpret.saliency_interpreters

.. automodule:: allennlp.interpret
   :members:
   :undoc-members:
   :show-inheritance:
