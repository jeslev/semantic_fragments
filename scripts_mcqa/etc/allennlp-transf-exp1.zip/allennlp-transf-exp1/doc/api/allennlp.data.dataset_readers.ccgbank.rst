allennlp.data.dataset_readers.ccgbank
====================================================

.. automodule:: allennlp.data.dataset_readers.ccgbank
   :members:
   :undoc-members:
   :show-inheritance:
