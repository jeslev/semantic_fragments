allennlp.data.dataset_readers.semantic_dependency_parsing
=========================================================

.. automodule:: allennlp.data.dataset_readers.semantic_dependency_parsing
   :members:
   :undoc-members:
   :show-inheritance:
