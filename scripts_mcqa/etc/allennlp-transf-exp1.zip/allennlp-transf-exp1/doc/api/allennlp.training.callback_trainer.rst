allennlp.training.callback_trainer
======================================

.. automodule:: allennlp.training.callback_trainer
   :members:
   :undoc-members:
   :show-inheritance:
