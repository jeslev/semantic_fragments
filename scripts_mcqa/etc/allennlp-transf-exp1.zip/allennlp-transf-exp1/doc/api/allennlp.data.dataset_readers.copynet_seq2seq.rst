allennlp.data.dataset_readers.copynet_seq2seq
==============================================

.. automodule:: allennlp.data.dataset_readers.copynet_seq2seq
   :members:
   :undoc-members:
   :show-inheritance:
