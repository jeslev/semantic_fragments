allennlp.data.dataset_readers.reading_comprehension
===================================================

.. automodule:: allennlp.data.dataset_readers.reading_comprehension
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.drop
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.squad
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.triviaqa
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.quac
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.qangaroo
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.util
   :members:
   :undoc-members:
   :show-inheritance:
