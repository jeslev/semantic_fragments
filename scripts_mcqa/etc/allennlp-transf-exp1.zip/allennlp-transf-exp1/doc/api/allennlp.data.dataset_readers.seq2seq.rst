allennlp.data.dataset_readers.seq2seq
==============================================

.. automodule:: allennlp.data.dataset_readers.seq2seq
   :members:
   :undoc-members:
   :show-inheritance:
