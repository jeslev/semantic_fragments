allennlp.data.dataset_readers.semantic_parsing
==============================================

.. toctree::

   allennlp.data.dataset_readers.semantic_parsing.wikitables

.. automodule:: allennlp.data.dataset_readers.semantic_parsing
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.atis
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.nlvr
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.template_text2sql
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.grammar_based_text2sql
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.semantic_parsing.quarel
   :members:
   :undoc-members:
   :show-inheritance:
