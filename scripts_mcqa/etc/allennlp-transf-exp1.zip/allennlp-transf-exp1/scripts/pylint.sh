#!/usr/bin/env bash
# Run our linter over the python code.

./scripts/verify.py --checks pylint
